var config = {
  // development: {
  //   host:     'localhost',
  //   port:     '5432',
  //   database: 'eulagy',
  //   user:     'eulagy_user',
  //   password: 'abcd!1234'
  // },
  // test: {
  //   host:     'localhost',
  //   port:     '5432',
  //   database: 'eulagy_test',
  //   user:     'eulagy_test',
  //   password: 'abcd!1234'
  // },
  development: {
    host:     'eulagy.cvzhg1lmv0zw.us-east-1.rds.amazonaws.com',
    port:     '5432',
    database: 'eulagy',
    user:     'eulagy_user',
    password: '^m^!Z!FMprEYSRE^YW47'
  },
  test: {
    host:     'eulagytest.cvzhg1lmv0zw.us-east-1.rds.amazonaws.com',
    port:     '5432',
    database: 'eulagy_test',
    user:     'eulagy_test',
    password: '!RQ9ngDUrxUFX%vBAfM4'
  }
};

module.exports = config;
